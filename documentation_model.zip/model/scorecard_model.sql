WITH woe_cte AS (
  SELECT
    CASE
        WHEN credit_score < 561.0 THEN -0.2253258161
        WHEN credit_score >= 561.0 AND credit_score < 583.0 THEN -0.0524369154
        WHEN credit_score >= 583.0 AND credit_score < 638.0 THEN -0.0308759864
        WHEN credit_score >= 638.0 AND credit_score < 694.0 THEN 0.0306009464
        WHEN credit_score >= 694.0 AND credit_score < 769.0 THEN 0.0842517029
        WHEN credit_score >= 769.0 THEN 0.2686690666
        ELSE 0.0
    END AS credit_score_WOE,
    CASE
        WHEN country = 'France' THEN 0.3203467192
        WHEN country = 'Spain' THEN 0.1698783805
        WHEN country = 'Germany' THEN -0.62635453
        ELSE 0.0
    END AS country_WOE,
    CASE
        WHEN gender = 'Male' THEN 0.2551712488
        WHEN gender = 'Female' THEN -0.2673679381
        ELSE 0.0
    END AS gender_WOE,
    CASE
        WHEN age < 26.0 THEN 1.3497813491
        WHEN age >= 26.0 AND age < 37.0 THEN 0.8738142607
        WHEN age >= 37.0 AND age < 40.0 THEN 0.3743459424
        WHEN age >= 40.0 AND age < 43.0 THEN 0.0005179192
        WHEN age >= 43.0 AND age < 45.0 THEN -0.5267714306
        WHEN age >= 45.0 THEN -1.1164742879
        ELSE 0.0
    END AS age_WOE,
    CASE
        WHEN balance < 24043.45 THEN 0.4530721151
        WHEN balance >= 24043.45 AND balance < 87541.06 THEN 0.1855888968
        WHEN balance >= 87541.06 AND balance < 99141.86 THEN 0.0183608916
        WHEN balance >= 99141.86 THEN -0.3003798266
        ELSE 0.0
    END AS balance_WOE,
    CASE
        WHEN products_number < 2.0 THEN -0.3975960343
        WHEN products_number >= 2.0 THEN 0.533134813
        ELSE 0.0
    END AS products_number_WOE,
    CASE
        WHEN credit_card < 1.0 THEN -0.0329313532
        WHEN credit_card >= 1.0 THEN 0.0139889674
        ELSE 0.0
    END AS credit_card_WOE
  FROM your_input_table
),
linear_score_cte AS (
  SELECT
    credit_score_WOE * -0.7093114537 +
    country_WOE * -0.7882234936 +
    gender_WOE * -0.9733246436 +
    age_WOE * -0.9649400808 +
    balance_WOE * -0.6215667807 +
    products_number_WOE * 3.5093356318 +
    credit_card_WOE * -0.0437631113 +
    1.328919315165029 AS LINEAR_SCORE,
    wc.*
  FROM woe_cte   wc
)
SELECT
  1 / (1 + EXP(-LINEAR_SCORE)) AS SCORE,
  lsc.*
FROM linear_score_cte  lsc;